<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dd_profile</name>
   <tag></tag>
   <elementGuidId>2e866e18-2beb-4c7f-9191-c661afc41e01</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//i[@class='c-icon c-icon--arrow-dropdown u-txt--large']</value>
   </webElementProperties>
</WebElementEntity>
