<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>textlink_login</name>
   <tag></tag>
   <elementGuidId>34308ef9-8aee-4a26-94ed-0a6d94b43bd8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[@class='c-btn c-btn--ghost c-btn--tiny c-btn--block js-dropdown-toggle js-track-login']</value>
   </webElementProperties>
</WebElementEntity>
