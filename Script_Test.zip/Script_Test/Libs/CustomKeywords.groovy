
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String


def static "WebUtility.openUrl"(
    	String email	) {
    (new WebUtility()).openUrl(
        	email)
}

def static "WebUtility.login"(
    	String email	
     , 	String password	) {
    (new WebUtility()).login(
        	email
         , 	password)
}
