import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.openqa.selenium.WebDriver
import org.testng.Assert

import com.google.common.collect.FilteredEntryMultimap.Keys
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser(null)
WebUI.navigateToUrl(GlobalVariable.Web_url)
WebDriver driver= DriverFactory.getWebDriver()
WebUI.maximizeWindow()
KeywordLogger log = new KeywordLogger()
WebUI.delay(3)

String product ="keyboard"
WebUI.click(findTestObject('Object Repository/search_field'))
WebUI.setText(findTestObject('Object Repository/search_field'), product)
WebUI.sendKeys(findTestObject('Object Repository/search_field'), org.openqa.selenium.Keys.chord(Keys.ENTER))

'Verify product match with product name'
String searchResult = WebUI.getText(findTestObject('Object Repository/product_name')).toLowerCase()
println(searchResult)
Assert.assertTrue(searchResult.contains(product))

WebUI.closeBrowser()