import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class WebUtility {
	WebDriver driver = DriverFactory.getWebDriver()
	KeywordLogger log= new KeywordLogger()

	public int currDiscountShipingCost;
	public int currtotalPayment;
	public int currshippingCost;
	public int currSubTotalPrice;

	public double calcTotalPayment;

	@Keyword
	def openUrl(String email){
		WebUI.navigateToUrl(email, FailureHandling.STOP_ON_FAILURE)
		log.logInfo(WebUI.getUrl())
		WebUI.waitForPageLoad(30)
		WebUI.maximizeWindow()
		WebUI.delay(3)
	}

	@Keyword
	def login(String email, String password) {
		WebUI.setViewaitForElementClickable(findTestObject('Object Repository/textlink_login'), 10)
		WebUI.click(findTestObject('Object Repository/textlink_login'))
		WebUI.delay(2)
		WebUI.verifyElementVisible(findTestObject('Object Repository/Login/inputEmail'))

		'Input Email & Password'
		WebUI.setText(findTestObject('Object Repository/input_email'), email)
		WebUI.setText(findTestObject('Object Repository/input_pswd'), password)
		WebUI.click(findTestObject('Object Repository/btnLogin'))
		WebUI.waitForPageLoad(30)
		WebUI.delay(3)
	}
}
